export default function(config) {
    return new Promise( function(resolve, reject) {
        resolve();
    } );
}