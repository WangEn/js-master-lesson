# axios examples

To run the examples:

1. `git clone https://github.com/axios/axios.git`
2. `cd axios`
3. `npm install`
4. `grunt build`
5. `npm run examples`
6. [http://localhost:3000](http://localhost:3000)
